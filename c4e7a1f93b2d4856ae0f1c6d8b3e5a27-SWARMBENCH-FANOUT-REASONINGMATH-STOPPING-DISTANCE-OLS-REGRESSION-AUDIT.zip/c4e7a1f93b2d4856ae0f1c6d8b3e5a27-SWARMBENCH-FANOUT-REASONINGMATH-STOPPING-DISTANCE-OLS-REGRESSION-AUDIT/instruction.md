# Stopping-distance OLS regression: derivation + twelve-derivation audit

## What you are doing
You are the lead reviewer for a statistics QA pipeline. A real dataset of 50 cars
(speed in mph, stopping distance in feet) was given to twelve AI assistants, each
asked to fit the ordinary-least-squares (OLS) regression of `dist` on `speed` and
report the slope with a 95% confidence interval. Your job has two parts:

1. **Derive the gold answer yourself**, from first principles, on all 50 points.
2. **Audit each of the twelve candidate solutions**, deciding whether its final
   answer is correct and assigning the exact set of failure codes it exhibits.

## Inputs (under `/workspace/input_artifacts/`)
- `problem.md` — the regression problem, the OLS method, and the 50-row data table.
- `cars.csv` — the authoritative 50 `speed,dist` observations.
- `provenance.md` — data source and notes on the candidate solutions.
- `proposed_solutions/response_A.md` ... `response_L.md` — the twelve candidate
  derivations to audit. They are raw model outputs: some are correct, some are
  wrong, some are correct-by-number but flawed-by-method. They do not contain
  answer keys.

## Part 1 — Gold derivation
Fit `dist = beta0 + beta1*speed` by OLS on all 50 observations, raw scale, nothing
dropped:
- `xbar = mean(speed)`, `ybar = mean(dist)`.
- `Sxx = sum((x-xbar)^2)`, `Syy = sum((y-ybar)^2)`, `Sxy = sum((x-xbar)(y-ybar))`.
- `beta1 = Sxy/Sxx` (the slope; **not** the Pearson `r = Sxy/sqrt(Sxx*Syy)`, and
  **not** the reverse regression `Sxy/Syy`), `beta0 = ybar - beta1*xbar`.
- `SSE = sum((y - beta0 - beta1*x)^2)`, `df = n-2 = 48`, `s = sqrt(SSE/df)`.
- `se(beta1) = s/sqrt(Sxx)`; 95% CI `= beta1 +/- t*(0.975, 48) * se(beta1)`.

Report the slope scaled by 1000 and rounded to the nearest integer as
`gold_slope_x1000`.

## Part 2 — Audit each candidate
For every response A..L decide:

**(a) `final_answer_correct`** — `true` iff the candidate's reported OLS slope is
within **+/- 0.03** of the gold slope, **and** its reported intercept is within
**+/- 0.3** of the gold intercept, **and** its reported 95% CI bounds are each
within **+/- 0.1** of the gold 95% CI. Otherwise `false`.

**(b) `failure_reasons`** — the SET of codes the candidate actually commits:

- **F1 — wrong regression direction.** Regresses speed on distance / swaps the
  axes / divides the cross-product by `Syy` instead of `Sxx`, yielding a slope
  near 0.166.
- **F2 — correlation reported as slope.** Reports the Pearson correlation `r`
  (~0.807) or `R^2` (~0.651) as the regression slope.
- **F3 — regression forced through the origin.** Drops the intercept term / fits
  `dist = beta1*speed` with `beta1 = sum(xy)/sum(x^2)` (~2.91).
- **F4 — wrong CI quantile.** Builds the 95% CI with the normal multiplier 1.96
  instead of the Student-t quantile `t*(0.975, n-2)`.
- **F5 — dropped or excluded data.** Fits on fewer than 50 observations (e.g.,
  excludes "outliers"), so `n != 50`.
- **F6 — arithmetic slip.** A purely computational error in a reported quantity
  (`Sxx`, `Sxy`, `Syy`, `sum(xy)`, `SSE`, a coefficient, or a CI bound) that is
  inconsistent with the data and is NOT explained by any method choice in F1–F5.
  You can only detect this by **recomputing the quantity yourself** — the
  candidate will present the wrong value as if it were correct.

**Trigger discipline (read carefully):**
- A code fires only if the candidate **commits** the error in its actual
  computation. The errors are **not announced**: candidates present flawed
  working as if it were correct, so you must re-derive each quantity and the
  failure-code set yourself rather than trust the candidate's own labelling.
- If a candidate **names a method only to reject it** (e.g., "some people swap
  the axes or quote r as the slope, but I do not"), those codes do **NOT** fire.
  Quoting a trigger phrase inside a refutation is not committing the error.
- Codes **co-fire**: a single candidate can commit several errors at once (e.g.,
  forcing the origin AND using 1.96 AND dropping points). List every committed
  code; missing one zeroes the whole response under all-or-nothing scoring.
- A numerically correct final answer can still carry a code (e.g., a candidate
  that reports the right slope but quietly builds its CI with 1.96 commits F4
  while remaining `final_answer_correct = true`).
- `failure_reasons` is a SET: list each committed code exactly once; an empty
  list `[]` means no failure.

A candidate is **acceptable** iff `final_answer_correct == true` AND
`failure_reasons == []`. Put all acceptable ids in `acceptable_solution_ids`.

## Output — write `/logs/agent/output.json`
Exactly these three top-level keys, nothing else:

```json
{
  "gold_slope_x1000": 0000,
  "acceptable_solution_ids": ["X", "Y"],
  "per_response_assessment": [
    {"response_id": "A", "final_answer_correct": true,  "failure_reasons": []},
    {"response_id": "B", "final_answer_correct": false, "failure_reasons": ["F2", "F4"]}
  ]
}
```

(SHAPE ONLY. The integer, the ids, and the verdicts above are dummy placeholders
— do not copy them; derive every real value yourself. The per_response_assessment
must contain all twelve entries A..L.)

Schema rules (any violation scores 0):
- `gold_slope_x1000` is an integer.
- `acceptable_solution_ids` is a list of distinct ids drawn from A..L.
- `per_response_assessment` has **exactly 12** entries, one per id, in
  **alphabetical order A..L**.
- Each entry has exactly `response_id`, `final_answer_correct` (boolean), and
  `failure_reasons` (list of codes from {F1,F2,F3,F4,F5,F6}, no duplicates).
- No extra top-level keys; no extra per-entry keys.

## Verification
An automated judge (`tests/judge.py`) scores `/logs/agent/output.json` against the
hidden oracle `/tests/oracle.json` on a **364-point** rubric, then divides by 364:
- `gold_slope_x1000`: 2 pts (within +/- 1 of the oracle integer).
- `acceptable_solution_ids`: 2 pts (set equality).
- Each response A..L: 30 pts **all-or-nothing**, awarded only if `response_id`,
  `final_answer_correct`, and the SET of `failure_reasons` all match the oracle
  (12 x 30 = 360).

Structural violations (wrong keys, wrong count, wrong order, non-boolean fields,
forbidden codes) fail closed to 0.0. A submission byte-identical to the oracle
scores 1.0; otherwise the maximum awardable score is capped at 0.99.
