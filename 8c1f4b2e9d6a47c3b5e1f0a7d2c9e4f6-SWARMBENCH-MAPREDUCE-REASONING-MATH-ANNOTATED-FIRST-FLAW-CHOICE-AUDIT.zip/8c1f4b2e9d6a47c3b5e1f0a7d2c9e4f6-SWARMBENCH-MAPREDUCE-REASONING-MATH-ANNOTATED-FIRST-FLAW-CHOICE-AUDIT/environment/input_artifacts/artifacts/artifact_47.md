# artifact_47

Competition: BMOSL  
Problem ID: BMOSL_2019_17  
Year: 2019

From the Open Proof Corpus benchmark set. One of the four candidate excerpts below corresponds to the first step that was marked unrecoverable by a human reviewer of this proof attempt. The excerpts appear in randomized order. Select the correct letter.

## Problem

Let \(f : \mathbb{Z} \to \mathbb{Z}\) satisfy \(f(x + y) = f(x) + f(y)\) for all \(x, y \in \mathbb{Z}\).
Prove that \(f(n) = n \cdot f(1)\) for all integers \(n\).

## Candidate Excerpts

### Option A

```text
The functional equation \(f(x+y)=f(x)+f(y)\) shows \(f\) is additive.
Additivity over \(\mathbb{Z}\) implies \(f\) is a group homomorphism from \((\mathbb{Z},+)\) to
\((\mathbb{Z},+)\).  Every group homomorphism from \(\mathbb{Z}\) is determined by the image
of the generator \(1\), and the only homomorphisms \(\mathbb{Z} \to \mathbb{Z}\) are \(n \mapsto cn\)
for \(c \in \mathbb{Z}\).  Hence \(f(n) = f(1) \cdot n\) follows immediately from the
classification of \(\mathbb{Z}\)-module homomorphisms, with no further computation needed.
```

### Option B

```text
\(f(0) = 0\): set \(x=y=0\): \(f(0)=2f(0)\), so \(f(0)=0\). \checkmark
```

### Option C

```text
For \(n \ge 1\): by induction.  \(f(k+1)=f(k)+f(1)=(k+1)f(1)\). \checkmark
For \(n < 0\): \(f(-m)=-f(m)=-mf(1)\). \checkmark
```

### Option D

```text
Therefore \(f(n) = nf(1)\) for all \(n \in \mathbb{Z}\).  \(\square\)
```

## Full Candidate Proof

```text
Option A invokes the "classification of ℤ-module homomorphisms" as if it is a
known fact that can be cited without proof.  But the statement being proved IS
that f(n) = n·f(1), which is exactly the content of the classification.
Citing the conclusion as a known result is circular: the classification theorem
IS what needs to be proved here. Options B,C,D give the actual elementary proof.
□
```

## Reviewer Note

The proof invokes a classification theorem whose content is precisely the statement to be proved, making the argument circular from the very first step.
