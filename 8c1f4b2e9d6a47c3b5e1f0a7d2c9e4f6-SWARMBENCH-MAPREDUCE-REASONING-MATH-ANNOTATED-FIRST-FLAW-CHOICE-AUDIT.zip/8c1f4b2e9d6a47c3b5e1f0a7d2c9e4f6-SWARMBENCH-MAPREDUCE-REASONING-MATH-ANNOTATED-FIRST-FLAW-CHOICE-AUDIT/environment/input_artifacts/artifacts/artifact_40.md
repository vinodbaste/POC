# artifact_40

Competition: USAMO  
Problem ID: USAMO_2017_6  
Year: 2017

OPC audit entry. A human annotator reviewing this incorrect olympiad proof marked the first unrecoverable flaw. Four candidate windows have been curated and randomly labeled A–D. Choose the label of the window that contains the human-marked flaw.

## Problem

Let \(a, b\) be integers with \(b \ne 0\).  Prove that \(\gcd(a, b) = \gcd(a, a+b)\).

## Candidate Excerpts

### Option A

```text
Write \(\mathcal{D}(m, n)\) for the set of positive common divisors of integers \(m\) and \(n\).
We claim \(\mathcal{D}(a, b) = \mathcal{D}(a, a+b)\).
```

### Option B

```text
\(\mathcal{D}(a,b) \subseteq \mathcal{D}(a,a+b)\):  If \(d \mid a\) and \(d \mid b\),
then \(d \mid a + b\), so \(d \in \mathcal{D}(a, a+b)\).
```

### Option C

```text
\(\mathcal{D}(a,a+b) \subseteq \mathcal{D}(a,b)\):  If \(d \mid a\) and \(d \mid a+b\),
then \(d \mid (a+b) - a = b\), so \(d \in \mathcal{D}(a, b)\).
```

### Option D

```text
Since \(\mathcal{D}(a,b) = \mathcal{D}(a,a+b)\) (both directions proved), the two sets
are equal.  In particular \(\max \mathcal{D}(a,b) = \max \mathcal{D}(a,a+b)\).
But \(\max \mathcal{D}(a,b)\) exists only if \(a\) and \(b\) are not both zero and at
least one is nonzero.  The problem states \(b \ne 0\), but does not guarantee \(a \ne 0\).
If \(a = 0\): \(\gcd(0, b) = b\) but \(\gcd(0, 0+b) = \gcd(0, b) = b\), so equality
holds trivially.  We must handle \(a = 0\) separately before taking the max.
```

## Full Candidate Proof

```text
D(a,b) = D(a,a+b) by Options B and C. Then gcd(a,b) = max D(a,b) = max D(a,a+b) = gcd(a,a+b).

Option D claims: since a=0 is not excluded, we must handle a=0 separately before taking
the maximum.  But D(0,b) = D(0,0+b) = D(0,b) — the sets are trivially equal when a=0,
so gcd(0,b)=gcd(0,b) holds without any special argument.  Option D manufactures a
non-issue: the set-equality proof in Options B and C already covers a=0, since divisibility
of 0 by d holds for all d.  The claim that "we must handle a=0 separately" is the first
unrecoverable logical error — it introduces a fake case split that undermines the proof's
completeness without identifying a real gap.
```

## Reviewer Note

After correctly establishing the equality of the two divisor sets, the conclusion step manufactures a spurious case split on \(a = 0\) that does not correspond to any gap in the preceding argument.
