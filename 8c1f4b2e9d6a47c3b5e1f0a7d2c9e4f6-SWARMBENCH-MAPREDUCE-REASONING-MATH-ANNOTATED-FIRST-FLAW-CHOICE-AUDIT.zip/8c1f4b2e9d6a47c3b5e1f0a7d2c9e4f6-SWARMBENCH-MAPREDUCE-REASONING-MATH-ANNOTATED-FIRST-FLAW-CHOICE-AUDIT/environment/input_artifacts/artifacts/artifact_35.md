# artifact_35

Competition: BMOSL  
Problem ID: BMOSL_2015_8  
Year: 2015

OPC audit entry. A human annotator reviewing this incorrect olympiad proof marked the first unrecoverable flaw. Four candidate windows have been curated and randomly labeled A–D. Choose the label of the window that contains the human-marked flaw.

## Problem

Let \(a, b\) be integers with \(b \ne 0\).  Prove that \(\gcd(a, b) = \gcd(a, a+b)\).

## Candidate Excerpts

### Option A

```text
Let \(d_1 = \gcd(a,b)\) and \(d_2 = \gcd(a, a+b)\).  We show \(d_1 \mid d_2\) and \(d_2 \mid d_1\).
```

### Option B

```text
\(d_1 \mid d_2\): \(d_1 \mid a\) and \(d_1 \mid b\), so \(d_1 \mid a+b\).
Thus \(d_1\) is a common divisor of \(a\) and \(a+b\), hence \(d_1 \mid d_2\).
```

### Option C

```text
\(d_2 \mid d_1\): \(d_2 \mid a\) and \(d_2 \mid (a+b)\).  Since \(a+b \equiv 0 \pmod{d_2}\)
and \(a \equiv 0 \pmod{d_2}\), we get \(a+b - b \equiv 0 \pmod{d_2}\), i.e.\ \(a \equiv b \pmod{d_2}\).
Hence \(d_2 \mid \gcd(a,b) = d_1\).
```

### Option D

```text
Combining: \(d_1 \mid d_2\) and \(d_2 \mid d_1\), so \(d_1 = d_2\).  \(\square\)
```

## Full Candidate Proof

```text
Option C claims: d₂|a and d₂|(a+b) → a+b - b ≡ 0 mod d₂, i.e., a ≡ b mod d₂.
Error: (a+b) - a = b, not (a+b) - b = a.  The correct step is:
d₂|(a+b) and d₂|a → d₂|(a+b-a) = d₂|b.
So d₂|a and d₂|b → d₂|gcd(a,b) = d₁.

The excerpt writes "(a+b) - b ≡ 0" which subtracts b (not a), deriving
a ≡ b mod d₂ — a meaningless relation that doesn't give d₂|b.  □
```

## Reviewer Note

The subtraction used to isolate \(b\) from \(a+b\) subtracts the wrong quantity, making the congruence relation meaningless for the intended conclusion.
