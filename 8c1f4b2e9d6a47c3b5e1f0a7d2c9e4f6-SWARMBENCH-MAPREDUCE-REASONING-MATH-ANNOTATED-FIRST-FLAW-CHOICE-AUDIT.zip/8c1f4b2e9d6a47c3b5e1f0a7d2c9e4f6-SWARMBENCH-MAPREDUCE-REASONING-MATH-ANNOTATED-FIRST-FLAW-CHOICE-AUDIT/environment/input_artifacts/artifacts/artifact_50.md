# artifact_50

Competition: BMOSL  
Problem ID: BMOSL_2018_9  
Year: 2018

You are reviewing a real human annotation from the Open Proof Corpus. A curator converted one free-form annotation into four candidate proof excerpts. Exactly one candidate excerpt contains the human-marked first unrecoverable flaw in this incorrect proof attempt. Choose the correct option letter. The candidate excerpts are presented in a randomized order.

## Problem

Let \(r\) and \(s\) be the two roots of \(x^2 + px + q = 0\).  Prove that \(r + s = -p\) and \(rs = q\).

## Candidate Excerpts

### Option A

```text
Since \(r\) and \(s\) are roots, \(r^2 + pr + q = 0\) and \(s^2 + ps + q = 0\).
Subtracting: \(r^2 - s^2 + p(r - s) = 0\), i.e.\ \((r-s)(r+s+p) = 0\).
```

### Option B

```text
Either \(r = s\) or \(r + s = -p\).  Adding the two root equations instead:
\((r^2 + s^2) + p(r+s) + 2q = 0\).  Write \(r^2+s^2 = (r+s)^2 - 2rs\).
Substituting: \((r+s)^2 - 2rs + p(r+s) + 2q = 0\).
```

### Option C

```text
If \(r \ne s\) the subtraction in Option A gives \(r + s = -p\) directly.
If \(r = s\): then from \(r^2 + pr + q = 0\) and \(s = r\), both roots equal \(-p/2\),
so \(r + s = -p\) in this case too.  Hence \(r + s = -p\) always.
```

### Option D

```text
For \(rs = q\): from the factorisation \(x^2 + px + q = (x-r)(x-s)\), expanding gives
\(x^2 - (r+s)x + rs\).  Comparing constant terms: \(q = rs\).
Using \(r+s = -p\) (established): \(x^2 + px + q = (x-r)(x-s)\) requires
\(-( r+s) = p\) and \(rs = q\), confirming both Vieta relations simultaneously.
But from Option B's equation: \((r+s)^2 - 2rs + p(r+s) + 2q = 0\).
Substituting \(r+s=-p\): \(p^2 - 2rs - p^2 + 2q = 0\), so \(2q = 2rs\), i.e.\ \(q = rs\). \checkmark
However, this only confirms \(q=rs\) when \(r+s=-p\) is already known, making Option B's
equation redundant — and Option B's equation was derived without using the factorisation,
so it provides an independent check.  The conclusion should state: \(q = rs\) follows from
Option B independently of Option D's factorisation argument.  Option D's argument is
therefore circular: it uses the factorisation to prove \(q=rs\), then invokes Option B to
"confirm" it, but Option B itself implicitly assumes the factorisation holds.
```

## Full Candidate Proof

```text
Options A and C together prove r+s=-p by case split on r=s vs r≠s.
Option D proves q=rs by factorisation comparison (direct, correct).

But Option D then claims Option B provides an "independent check" of q=rs,
and labels Option D's factorisation argument as "confirmed" by Option B.
The circularity: Option B was derived from the root equations (r²+pr+q=0, s²+ps+q=0),
which are equivalent to x²+px+q=(x-r)(x-s) — the same factorisation Option D uses.
So Option B is NOT independent; both derive from the same factorisation.
Labelling Option B's check as "independent" is the first unrecoverable logical error.
```

## Reviewer Note

After correctly proving \(rs=q\) by factorisation comparison, the step labels a redundant check as an "independent confirmation" when both arguments rest on the same factorisation identity.
