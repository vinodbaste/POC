# artifact_44

Competition: BMOSL  
Problem ID: BMOSL_2023_7  
Year: 2023

From the Open Proof Corpus benchmark set. One of the four candidate excerpts below corresponds to the first step that was marked unrecoverable by a human reviewer of this proof attempt. The excerpts appear in randomized order. Select the correct letter.

## Problem

In triangle \(ABC\) with semiperimeter \(s\), the incircle touches \(BC\), \(CA\), \(AB\) at \(D\), \(E\), \(F\) respectively.  Prove that \(BD = s - b\), where \(a = BC\), \(b = CA\), \(c = AB\).

## Candidate Excerpts

### Option A

```text
Let \(BD = x\).  Tangent segments from an external point to a circle are equal:
\(BD = BF = x\) and \(CD = CE = a - x\).
```

### Option B

```text
From vertex \(A\): \(AE = AC - CE = b - (a - x) = b - a + x\)
and \(AF = AB - BF = c - x\).  Setting \(AE = AF\):
\(b - a + x = c - x\), so \(2x = a + c - b\), giving \(x = \dfrac{a+c-b}{2} = s - b\).
```

### Option C

```text
Consistency check: \(BD + DC = x + (a - x) = a = BC\).  \checkmark
Also, \(AE + EC = (s-b) + (s-c)\).  But \(AE + EC\) should equal \(AC = b\).
And indeed \((s-b)+(s-c) = 2s - b - c = a + b + c - b - c = a = BC\), not \(b\).
```

### Option D

```text
Correcting: \(AE = s - a\) (tangent from \(A\)), and \(CE = s - c\).
Then \(AE + EC = (s-a)+(s-c) = 2s - a - c = b = CA\).  \checkmark
Hence \(BD = s-b\) and all tangent lengths are confirmed.  \(\square\)
```

## Full Candidate Proof

```text
BD = BF = x, CD = CE = a-x. AE = b-a+x, AF = c-x.
2x = a+c-b → x = s-b ✓.

Option C claims AE+EC = (s-b)+(s-c) = a — mixing up AE=s-b (wrong; AE=s-a)
with CE=s-c. The correct values are AE=s-a and CE=s-c, giving AE+EC=b ✓.

Option D corrects the error.
BD = s-b is established. □
```

## Reviewer Note

The consistency verification conflates two different tangent lengths — it assigns \(s-b\) to the wrong vertex's tangent segment when checking that \(AE + EC = b\).
