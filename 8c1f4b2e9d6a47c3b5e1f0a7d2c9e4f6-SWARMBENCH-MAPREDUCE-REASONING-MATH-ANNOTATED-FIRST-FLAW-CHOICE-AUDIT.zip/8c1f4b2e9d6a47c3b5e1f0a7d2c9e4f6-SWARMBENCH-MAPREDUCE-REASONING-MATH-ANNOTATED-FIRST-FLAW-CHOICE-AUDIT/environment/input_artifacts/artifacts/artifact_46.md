# artifact_46

Competition: USAMO  
Problem ID: USAMO_2022_3  
Year: 2022

From the Open Proof Corpus benchmark set. One of the four candidate excerpts below corresponds to the first step that was marked unrecoverable by a human reviewer of this proof attempt. The excerpts appear in randomized order. Select the correct letter.

## Problem

Prove that for all real numbers \(a, b\):
\[
a^2 + b^2 \;\ge\; 2ab.
\]

## Candidate Excerpts

### Option A

```text
Write \(a^2 + b^2 - 2ab\) and aim to show it is non-negative.
```

### Option B

```text
Factor: \(a^2 - 2ab + b^2 = (a - b)^2\).
```

### Option C

```text
By the AM-GM inequality applied to \(a^2\) and \(b^2\):
\[
\frac{a^2 + b^2}{2} \;\ge\; \sqrt{a^2 \cdot b^2} = |ab| \;\ge\; ab.
\]
Hence \(a^2 + b^2 \ge 2|ab| \ge 2ab\).  This proves the inequality.
The factoring in Option B is therefore a redundant alternative approach.
```

### Option D

```text
In fact \((a-b)^2 \ge 0\) is the cleaner proof.  Expanding gives \(a^2-2ab+b^2 \ge 0\),
i.e.\ \(a^2+b^2 \ge 2ab\).  \(\square\)
```

## Full Candidate Proof

```text
Options A,B,D constitute a clean complete proof via (a-b)²≥0.

Option C uses AM-GM on a²,b² to get (a²+b²)/2 ≥ |ab| ≥ ab.
The step |ab| ≥ ab is correct (since |ab| = ab or |ab| = -ab ≥ ab if ab<0).
BUT Option C then labels Option B "redundant" when in fact Option C itself
introduces an UNNECESSARY intermediate step (|ab| ≥ ab) that is also less
direct than the (a-b)² approach.  The claim that Option B is "redundant" is
the first unrecoverable error: Option B is the primary proof; Option C's
AM-GM derivation is the redundant one, and its conclusion (a²+b²≥2|ab|)
is stronger than needed. □
```

## Reviewer Note

Option C incorrectly labels the direct algebraic proof in Option B as redundant, when in fact Option C introduces the unnecessary detour through absolute values.
